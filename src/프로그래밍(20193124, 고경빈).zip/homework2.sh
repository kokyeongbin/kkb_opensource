#!/bin/bash

read num

i=0
while [ $i -lt `expr $num` ]
do
	echo "hello world"
	i=`expr $i + 1`
done

exit 0
