#!/bin/sh

echo "is linux fun? (yes / no)"
read answer
case $answer in
	yes | y | Y | Yes | YES)
		echo "Good."
		echo "Good Luck ^^";;
	[nN]*)
		echo "Sorry.";;
	*)
		echo "you should type yes or no"
		exit 1;;
esac
exit 0
